<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireUser();
require_once __DIR__ . '/../config/db.php';

$uid = currentUserId();

// ── CANCEL ORDER ───────────────────────────────────────────
$success = ''; $error = '';
if (isset($_POST['action']) && $_POST['action'] === 'cancel') {
    $oid = intval($_POST['order_id']);
    $r   = $conn->query("SELECT status FROM fr_orders WHERE order_id=$oid AND user_id=$uid");
    $o   = $r ? $r->fetch_assoc() : null;
    if (!$o) {
        $error = "Order not found.";
    } elseif (!in_array($o['status'], ['pending', 'confirmed'])) {
        $error = "This order can no longer be cancelled.";
    } else {
        $conn->query("UPDATE fr_orders SET status='cancelled' WHERE order_id=$oid AND user_id=$uid");
        $success = "Order #$oid has been cancelled.";
    }
}

// ── Filter ─────────────────────────────────────────────────
$status_filt = $_GET['status'] ?? '';
$where = "WHERE o.user_id=$uid";
if (in_array($status_filt, ['pending','confirmed','preparing','ready','delivered','cancelled'])) {
    $where .= " AND o.status='$status_filt'";
}

$orders = $conn->query(
    "SELECT o.* FROM fr_orders o $where ORDER BY o.created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="section-header">
        <h2>📦 My Orders</h2>
        <a href="home.php" class="btn-primary-fr">+ New Order</a>
    </div>

    <!-- Filter -->
    <form method="GET" class="filter-bar mb-3">
        <select name="status">
            <option value="">All Status</option>
            <?php foreach (['pending','confirmed','preparing','ready','delivered','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $status_filt === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn-primary-fr">Filter</button>
        <a href="my_orders.php" class="btn-outline-fr">Reset</a>
    </form>

    <?php if ($orders && $orders->num_rows > 0): ?>
        <?php while ($o = $orders->fetch_assoc()): ?>

        <!-- Comprehensive card view per order -->
        <div class="fr-card mb-3">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                <div>
                    <h5 class="fw-bold mb-1">Order #<?= $o['order_id'] ?></h5>
                    <small class="text-muted"><?= date('F j, Y g:i A', strtotime($o['created_at'])) ?></small>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge-status badge-<?= $o['status'] ?>"><?= $o['status'] ?></span>
                    <span class="fw-bold" style="color:#e63946;font-size:18px;">₱<?= number_format($o['total_price'], 2) ?></span>
                </div>
            </div>

            <?php if ($o['notes']): ?>
                <p class="mt-2 mb-1" style="font-size:13px;color:#555;">
                    📝 <em><?= htmlspecialchars($o['notes']) ?></em>
                </p>
            <?php endif; ?>

            <!-- Order items -->
            <?php
            $items = $conn->query(
                "SELECT oi.quantity, oi.unit_price, f.name, f.image_url
                 FROM fr_order_items oi
                 JOIN fr_food_items f ON oi.item_id=f.item_id
                 WHERE oi.order_id={$o['order_id']}"
            );
            ?>
            <div class="d-flex flex-wrap gap-2 mt-3">
            <?php while ($oi = $items->fetch_assoc()): ?>
                <div style="background:#f8f9fa;border-radius:10px;padding:10px 14px;min-width:140px;font-size:13px;">
                    <?php if ($oi['image_url']): ?>
                        <img src="<?= htmlspecialchars($oi['image_url']) ?>" style="width:30px;height:30px;object-fit:cover;border-radius:6px;margin-right:6px;">
                    <?php else: ?> 🍔 <?php endif; ?>
                    <strong><?= htmlspecialchars($oi['name']) ?></strong><br>
                    ×<?= $oi['quantity'] ?> — ₱<?= number_format($oi['unit_price'] * $oi['quantity'], 2) ?>
                </div>
            <?php endwhile; ?>
            </div>

            <!-- Cancel button -->
            <?php if (in_array($o['status'], ['pending', 'confirmed'])): ?>
            <form method="POST" class="mt-3">
                <input type="hidden" name="action"   value="cancel">
                <input type="hidden" name="order_id" value="<?= $o['order_id'] ?>">
                <button type="submit" class="btn-danger-fr"
                        onclick="return confirm('Cancel this order?')">Cancel Order</button>
            </form>
            <?php endif; ?>

            <!-- Status tracker -->
            <div class="mt-3" style="font-size:12px;color:#888;">
                <?php
                $steps = ['pending','confirmed','preparing','ready','delivered'];
                $cur   = array_search($o['status'], $steps);
                foreach ($steps as $i => $step) {
                    $done    = $cur !== false && $i <= $cur && $o['status'] !== 'cancelled';
                    $active  = $cur !== false && $i === $cur && $o['status'] !== 'cancelled';
                    $color   = $done ? '#2d6a4f' : '#ccc';
                    echo "<span style='margin-right:6px;color:$color;font-weight:" . ($active ? '800' : '400') . "'>" . ucfirst($step) . ($i < count($steps)-1 ? ' →' : '') . "</span>";
                }
                if ($o['status'] === 'cancelled') echo " <span style='color:#c1121f;font-weight:800;'>Cancelled</span>";
                ?>
            </div>
        </div>

        <?php endwhile; ?>
    <?php else: ?>
        <div class="fr-card text-center py-5">
            <div style="font-size:56px;margin-bottom:16px;">📭</div>
            <h4>No orders yet.</h4>
            <p class="text-muted">Head to the menu and place your first order!</p>
            <a href="home.php" class="btn-primary-fr">Browse Menu</a>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
