<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireUser();
require_once __DIR__ . '/../config/db.php';

$uid     = currentUserId();
$success = ''; $error = '';

// ── SUBMIT RESERVATION ─────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'book') {
    $event_name  = trim($_POST['event_name']  ?? '');
    $event_date  = $_POST['event_date']       ?? '';
    $guest_count = intval($_POST['guest_count'] ?? 0);
    $package     = trim($_POST['package']     ?? '');
    $notes       = trim($_POST['notes']       ?? '');

    if (empty($event_name) || empty($event_date) || $guest_count < 1) {
        $error = "Event name, date, and guest count are required.";
    } elseif (strtotime($event_date) < strtotime(date('Y-m-d'))) {
        $error = "Event date must be today or in the future.";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO fr_reservations (user_id, event_name, event_date, guest_count, package, notes) VALUES (?,?,?,?,?,?)"
        );
        $stmt->bind_param("ississ", $uid, $event_name, $event_date, $guest_count, $package, $notes);
        $stmt->execute() ? $success = "Reservation submitted! We'll confirm it shortly." : $error = "Failed to submit. Please try again.";
        $stmt->close();
    }
}

// ── CANCEL RESERVATION ─────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'cancel') {
    $rid = intval($_POST['reservation_id']);
    $r   = $conn->query("SELECT status FROM fr_reservations WHERE reservation_id=$rid AND user_id=$uid");
    $res = $r ? $r->fetch_assoc() : null;
    if (!$res) { $error = "Reservation not found."; }
    elseif (!in_array($res['status'], ['pending'])) { $error = "Only pending reservations can be cancelled."; }
    else {
        $conn->query("UPDATE fr_reservations SET status='cancelled' WHERE reservation_id=$rid AND user_id=$uid");
        $success = "Reservation cancelled.";
    }
}

$my_reservations = $conn->query(
    "SELECT * FROM fr_reservations WHERE user_id=$uid ORDER BY created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catering – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="row g-4">

        <!-- ── Booking Form ── -->
        <div class="col-lg-5">
            <div class="fr-card">
                <h4 class="fw-bold mb-4">🎉 Book Catering</h4>
                <form method="POST">
                    <input type="hidden" name="action" value="book">
                    <div class="mb-3">
                        <label class="fr-form-label">Event Name *</label>
                        <input class="fr-form-control" type="text" name="event_name"
                               placeholder="e.g. Birthday Party, Corporate Lunch"
                               value="<?= htmlspecialchars($_POST['event_name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Event Date *</label>
                        <input class="fr-form-control" type="date" name="event_date"
                               min="<?= date('Y-m-d') ?>"
                               value="<?= htmlspecialchars($_POST['event_date'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Number of Guests *</label>
                        <input class="fr-form-control" type="number" name="guest_count" min="1"
                               placeholder="e.g. 50"
                               value="<?= htmlspecialchars($_POST['guest_count'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Package</label>
                        <select class="fr-form-control" name="package">
                            <option value="">-- Select Package (optional) --</option>
                            <option value="Basic Package">Basic Package</option>
                            <option value="Standard Package">Standard Package</option>
                            <option value="Premium Package">Premium Package</option>
                            <option value="Custom">Custom (specify in notes)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Notes / Special Requests</label>
                        <textarea class="fr-form-control" name="notes" rows="3"
                                  placeholder="Menu preferences, venue, dietary restrictions..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="btn-primary-fr w-100">Submit Reservation</button>
                </form>
            </div>
        </div>

        <!-- ── My Reservations ── -->
        <div class="col-lg-7">
            <div class="section-header"><h2>My Reservations</h2></div>

            <?php if ($my_reservations && $my_reservations->num_rows > 0): ?>
                <?php while ($res = $my_reservations->fetch_assoc()): ?>
                <div class="fr-card mb-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 class="fw-bold mb-1"><?= htmlspecialchars($res['event_name']) ?></h5>
                            <small class="text-muted">Submitted: <?= date('M j, Y', strtotime($res['created_at'])) ?></small>
                        </div>
                        <span class="badge-status badge-<?= $res['status'] ?>"><?= $res['status'] ?></span>
                    </div>
                    <div class="row mt-2 g-2" style="font-size:14px;">
                        <div class="col-6">📅 <strong>Event Date:</strong> <?= date('M j, Y', strtotime($res['event_date'])) ?></div>
                        <div class="col-6">👥 <strong>Guests:</strong> <?= $res['guest_count'] ?></div>
                        <div class="col-6">📦 <strong>Package:</strong> <?= htmlspecialchars($res['package'] ?? '—') ?></div>
                        <?php if ($res['notes']): ?>
                        <div class="col-12">📝 <?= htmlspecialchars($res['notes']) ?></div>
                        <?php endif; ?>
                    </div>
                    <?php if ($res['status'] === 'pending'): ?>
                    <form method="POST" class="mt-3">
                        <input type="hidden" name="action"         value="cancel">
                        <input type="hidden" name="reservation_id" value="<?= $res['reservation_id'] ?>">
                        <button type="submit" class="btn-danger-fr"
                                onclick="return confirm('Cancel this reservation?')">Cancel</button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="fr-card text-center py-5">
                    <div style="font-size:48px;">🎉</div>
                    <h5 class="mt-3">No reservations yet.</h5>
                    <p class="text-muted">Book catering for your next event!</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
