<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireUser();
require_once __DIR__ . '/../config/db.php';

$success = ''; $error = '';

// ── PLACE ORDER ────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'place_order') {
    $items  = $_POST['items']  ?? [];   // [item_id => qty]
    $notes  = trim($_POST['notes'] ?? '');
    $method = in_array($_POST['method'] ?? '', ['cash','gcash','card','others']) ? $_POST['method'] : 'cash';

    $item_ids = array_filter(array_keys($items), fn($id) => intval($items[$id]) > 0);

    if (empty($item_ids)) {
        $error = "Please select at least one item with a quantity greater than 0.";
    } else {
        $total = 0;
        $order_items = [];

        foreach ($item_ids as $id) {
            $id  = intval($id);
            $qty = intval($items[$id]);
            $r   = $conn->query("SELECT item_id, price, stock_qty, is_available FROM fr_food_items WHERE item_id=$id");
            $f   = $r ? $r->fetch_assoc() : null;

            if (!$f || !$f['is_available']) { $error = "One or more selected items are unavailable."; break; }
            if ($f['stock_qty'] < $qty)      { $error = "Not enough stock for one or more items."; break; }

            $order_items[] = ['item_id' => $id, 'qty' => $qty, 'price' => $f['price']];
            $total += $f['price'] * $qty;
        }

        if (!$error) {
            $conn->begin_transaction();
            try {
                $uid = currentUserId();
                $stmt = $conn->prepare("INSERT INTO fr_orders (user_id, total_price, notes) VALUES (?,?,?)");
                $stmt->bind_param("ids", $uid, $total, $notes);
                $stmt->execute();
                $order_id = $conn->insert_id;
                $stmt->close();

                foreach ($order_items as $oi) {
                    $s = $conn->prepare("INSERT INTO fr_order_items (order_id, item_id, quantity, unit_price) VALUES (?,?,?,?)");
                    $s->bind_param("iiid", $order_id, $oi['item_id'], $oi['qty'], $oi['price']);
                    $s->execute(); $s->close();

                    $conn->query("UPDATE fr_food_items SET stock_qty = stock_qty - {$oi['qty']} WHERE item_id = {$oi['item_id']}");
                }

                // Create pending payment
                $s = $conn->prepare("INSERT INTO fr_payments (order_id, user_id, amount, method) VALUES (?,?,?,?)");
                $s->bind_param("iids", $order_id, $uid, $total, $method);
                $s->execute(); $s->close();

                $conn->commit();
                $success = "Order placed! Order #$order_id has been submitted. Total: ₱" . number_format($total, 2);
            } catch (Exception $e) {
                $conn->rollback();
                $error = "Order failed. Please try again.";
            }
        }
    }
}

// ── LOAD MENU with search / filter ────────────────────────
$search   = trim($_GET['search']   ?? '');
$cat_filt = intval($_GET['cat']    ?? 0);

$where = "WHERE f.is_available=1";
if ($search)   $where .= " AND f.name LIKE '%" . $conn->real_escape_string($search) . "%'";
if ($cat_filt) $where .= " AND f.category_id=$cat_filt";

$food_items = $conn->query(
    "SELECT f.*, c.name AS cat_name FROM fr_food_items f
     JOIN fr_categories c ON f.category_id=c.category_id
     $where ORDER BY c.name, f.name"
);
$categories = $conn->query("SELECT * FROM fr_categories ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .qty-input { width: 70px; text-align: center; }
        .order-summary {
            position: sticky; top: 80px;
        }
        #summary-list { min-height: 60px; }
    </style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="row g-4">

        <!-- ── MENU ── -->
        <div class="col-lg-8">
            <div class="section-header">
                <h2>🍔 Order Your Food</h2>
            </div>

            <!-- Filter -->
            <form method="GET" class="filter-bar mb-3">
                <input type="text" name="search" placeholder="🔍 Search food..." value="<?= htmlspecialchars($search) ?>">
                <select name="cat">
                    <option value="">All Categories</option>
                    <?php while ($c = $categories->fetch_assoc()): ?>
                    <option value="<?= $c['category_id'] ?>" <?= $cat_filt == $c['category_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['name']) ?>
                    </option>
                    <?php endwhile; ?>
                </select>
                <button type="submit" class="btn-primary-fr">Filter</button>
                <a href="home.php" class="btn-outline-fr">Reset</a>
            </form>

            <form method="POST" id="order-form">
                <input type="hidden" name="action" value="place_order">

                <div class="food-grid" id="food-grid">
                <?php if ($food_items && $food_items->num_rows > 0): ?>
                    <?php while ($item = $food_items->fetch_assoc()): ?>
                    <div class="food-card">
                        <?php if ($item['image_url']): ?>
                            <img src="<?= htmlspecialchars($item['image_url']) ?>" class="food-img" alt="<?= htmlspecialchars($item['name']) ?>">
                        <?php else: ?>
                            <div class="food-img">🍽️</div>
                        <?php endif; ?>
                        <div class="food-body">
                            <div class="food-cat"><?= htmlspecialchars($item['cat_name']) ?></div>
                            <div class="food-name"><?= htmlspecialchars($item['name']) ?></div>
                            <div class="food-price">₱<?= number_format($item['price'], 2) ?></div>
                            <div class="food-stock mb-2">Stock: <?= $item['stock_qty'] ?></div>
                            <?php if ($item['description']): ?>
                                <p style="font-size:12px;color:#777;margin-bottom:10px;"><?= htmlspecialchars($item['description']) ?></p>
                            <?php endif; ?>
                            <input
                                type="number"
                                name="items[<?= $item['item_id'] ?>]"
                                class="fr-form-control qty-input item-qty"
                                value="0"
                                min="0"
                                max="<?= $item['stock_qty'] ?>"
                                data-name="<?= htmlspecialchars($item['name']) ?>"
                                data-price="<?= $item['price'] ?>"
                                data-id="<?= $item['item_id'] ?>"
                                placeholder="Qty"
                            >
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-muted">No items available.</p>
                <?php endif; ?>
                </div>

                <!-- Payment method -->
                <div class="fr-card mt-4">
                    <h5 class="fw-bold mb-3">Payment Method</h5>
                    <div class="d-flex gap-3 flex-wrap">
                        <?php foreach (['cash','gcash','card','others'] as $m): ?>
                        <label>
                            <input type="radio" name="method" value="<?= $m ?>" <?= $m === 'cash' ? 'checked' : '' ?>>
                            <?= ucfirst($m) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Notes -->
                <div class="fr-card mt-3">
                    <label class="fr-form-label">Special Notes / Instructions</label>
                    <textarea class="fr-form-control" name="notes" rows="2" placeholder="Allergy notes, delivery instructions..."></textarea>
                </div>

            </form>
        </div>

        <!-- ── ORDER SUMMARY ── -->
        <div class="col-lg-4">
            <div class="fr-card order-summary">
                <h5 class="fw-bold mb-3">🛒 Order Summary</h5>
                <div id="summary-list">
                    <p class="text-muted" id="empty-msg">Add items to your order.</p>
                </div>
                <hr>
                <div class="d-flex justify-content-between fw-bold">
                    <span>Total:</span>
                    <span id="summary-total">₱0.00</span>
                </div>
                <button type="submit" form="order-form" class="btn-primary-fr w-100 mt-3" id="place-btn">
                    Place Order
                </button>
                <a href="my_orders.php" class="btn-outline-fr w-100 mt-2 text-center">View My Orders</a>
            </div>
        </div>

    </div>
</div>

<script>
// Live order summary
const qtyInputs = document.querySelectorAll('.item-qty');
const summaryList = document.getElementById('summary-list');
const emptyMsg    = document.getElementById('empty-msg');
const totalEl     = document.getElementById('summary-total');

function updateSummary() {
    summaryList.innerHTML = '';
    let total = 0;
    qtyInputs.forEach(inp => {
        const qty = parseInt(inp.value) || 0;
        if (qty > 0) {
            const price = parseFloat(inp.dataset.price);
            const sub   = price * qty;
            total += sub;
            const row = document.createElement('div');
            row.className = 'd-flex justify-content-between mb-1';
            row.style.fontSize = '13px';
            row.innerHTML = `<span>${inp.dataset.name} × ${qty}</span><span>₱${sub.toFixed(2)}</span>`;
            summaryList.appendChild(row);
        }
    });
    totalEl.textContent = '₱' + total.toFixed(2);
    if (summaryList.children.length === 0) {
        const p = document.createElement('p');
        p.textContent = 'Add items to your order.';
        p.className = 'text-muted';
        summaryList.appendChild(p);
    }
}

qtyInputs.forEach(inp => inp.addEventListener('input', updateSummary));
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
