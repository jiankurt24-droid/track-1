<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireUser();
require_once __DIR__ . '/../config/db.php';

$uid     = currentUserId();
$success = ''; $error = '';

// ── UPDATE ACCOUNT ─────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update') {
    $full_name   = trim($_POST['full_name']   ?? '');
    $email       = trim($_POST['email']       ?? '');
    $phone       = trim($_POST['phone']       ?? '');
    $current_pw  = $_POST['current_password'] ?? '';
    $new_pw      = $_POST['new_password']     ?? '';
    $confirm_pw  = $_POST['confirm_password'] ?? '';

    if (empty($full_name) || empty($email)) {
        $error = "Name and email are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Fetch current record
        $r = $conn->query("SELECT * FROM users WHERE user_id=$uid");
        $user = $r ? $r->fetch_assoc() : null;

        if (!$user) {
            $error = "User not found.";
        } else {
            // Password change requested
            if (!empty($new_pw)) {
                if (!password_verify($current_pw, $user['password'])) {
                    $error = "Current password is incorrect.";
                } elseif (strlen($new_pw) < 8) {
                    $error = "New password must be at least 8 characters.";
                } elseif ($new_pw !== $confirm_pw) {
                    $error = "New passwords do not match.";
                } else {
                    $hashed = password_hash($new_pw, PASSWORD_BCRYPT);
                    $stmt = $conn->prepare("UPDATE users SET full_name=?,email=?,phone=?,password=? WHERE user_id=?");
                    $stmt->bind_param("ssssi", $full_name, $email, $phone, $hashed, $uid);
                }
            } else {
                $stmt = $conn->prepare("UPDATE users SET full_name=?,email=?,phone=? WHERE user_id=?");
                $stmt->bind_param("sssi", $full_name, $email, $phone, $uid);
            }

            if (!$error) {
                if ($stmt->execute()) {
                    $_SESSION['full_name'] = $full_name;
                    $_SESSION['email']     = $email;
                    $success = "Account updated successfully.";
                } else {
                    $error = $conn->errno === 1062 ? "Email already in use." : "Update failed.";
                }
                $stmt->close();
            }
        }
    }
}

// ── Fetch current user ─────────────────────────────────────
$r    = $conn->query("SELECT * FROM users WHERE user_id=$uid");
$user = $r ? $r->fetch_assoc() : [];

// ── Stats ─────────────────────────────────────────────────
$order_count = $conn->query("SELECT COUNT(*) FROM fr_orders WHERE user_id=$uid")->fetch_row()[0];
$total_spent = $conn->query("SELECT IFNULL(SUM(amount),0) FROM fr_payments WHERE user_id=$uid AND status='paid'")->fetch_row()[0];
$res_count   = $conn->query("SELECT COUNT(*) FROM fr_reservations WHERE user_id=$uid")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="row g-4">

        <!-- Profile Card -->
        <div class="col-lg-4">
            <div class="fr-card text-center">
                <div style="width:80px;height:80px;background:#111;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:32px;margin:0 auto 16px;">
                    👤
                </div>
                <h4 class="fw-bold"><?= htmlspecialchars($user['full_name'] ?? '') ?></h4>
                <p class="text-muted" style="font-size:14px;"><?= htmlspecialchars($user['email'] ?? '') ?></p>
                <span class="badge-status badge-<?= $user['role'] ?? 'user' ?>"><?= strtoupper($user['role'] ?? 'user') ?></span>
                <p class="text-muted mt-2" style="font-size:13px;">
                    Joined: <?= isset($user['created_at']) ? date('M j, Y', strtotime($user['created_at'])) : '—' ?>
                </p>
            </div>

            <!-- Quick stats -->
            <div class="fr-card mt-3">
                <h5 class="fw-bold mb-3">My Activity</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span>📦 Orders</span><strong><?= $order_count ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>🎉 Reservations</span><strong><?= $res_count ?></strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span>💰 Total Spent</span><strong style="color:#e63946;">₱<?= number_format($total_spent, 2) ?></strong>
                </div>
            </div>
        </div>

        <!-- Edit Form -->
        <div class="col-lg-8">
            <div class="fr-card">
                <h4 class="fw-bold mb-4">✏️ Edit Profile</h4>
                <form method="POST">
                    <input type="hidden" name="action" value="update">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="fr-form-label">Full Name *</label>
                            <input class="fr-form-control" type="text" name="full_name"
                                   value="<?= htmlspecialchars($user['full_name'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="fr-form-label">Email *</label>
                            <input class="fr-form-control" type="email" name="email"
                                   value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="fr-form-label">Phone</label>
                            <input class="fr-form-control" type="text" name="phone"
                                   value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="09XXXXXXXXX">
                        </div>
                    </div>

                    <hr class="my-4">
                    <h5 class="fw-bold mb-3">Change Password <small style="font-size:13px;font-weight:400;color:#888;">(leave blank to keep current)</small></h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="fr-form-label">Current Password</label>
                            <input class="fr-form-control" type="password" name="current_password">
                        </div>
                        <div class="col-md-4">
                            <label class="fr-form-label">New Password</label>
                            <input class="fr-form-control" type="password" name="new_password" minlength="8">
                        </div>
                        <div class="col-md-4">
                            <label class="fr-form-label">Confirm New Password</label>
                            <input class="fr-form-control" type="password" name="confirm_password">
                        </div>
                    </div>

                    <button type="submit" class="btn-primary-fr mt-4">Save Changes</button>
                </form>
            </div>

            <div class="text-center mt-4">
                <a href="../auth/logout.php" class="btn-danger-fr">Logout</a>
            </div>
        </div>

    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
