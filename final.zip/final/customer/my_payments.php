<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireUser();
require_once __DIR__ . '/../config/db.php';

$uid = currentUserId();

$payments = $conn->query(
    "SELECT p.*, o.total_price AS order_total FROM fr_payments p
     LEFT JOIN fr_orders o ON p.order_id=o.order_id
     WHERE p.user_id=$uid ORDER BY p.created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Payments – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">
    <div class="section-header"><h2>💳 My Payments</h2></div>

    <?php if ($payments && $payments->num_rows > 0): ?>
    <div class="row g-3">
        <?php while ($p = $payments->fetch_assoc()): ?>
        <div class="col-md-6">
            <div class="fr-card">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <h5 class="fw-bold mb-0">₱<?= number_format($p['amount'], 2) ?></h5>
                        <small class="text-muted"><?= date('M j, Y g:i A', strtotime($p['created_at'])) ?></small>
                    </div>
                    <span class="badge-status badge-<?= $p['status'] ?>"><?= $p['status'] ?></span>
                </div>
                <p style="font-size:14px;margin-bottom:4px;">
                    <strong>Method:</strong> <?= ucfirst($p['method']) ?>
                </p>
                <?php if ($p['order_id']): ?>
                <p style="font-size:14px;margin-bottom:4px;">
                    <strong>For:</strong> Order #<?= $p['order_id'] ?>
                </p>
                <?php endif; ?>
                <?php if ($p['reservation_id']): ?>
                <p style="font-size:14px;margin-bottom:4px;">
                    <strong>For:</strong> Reservation #<?= $p['reservation_id'] ?>
                </p>
                <?php endif; ?>
                <?php if ($p['paid_at']): ?>
                <p style="font-size:13px;color:#2d6a4f;margin-bottom:0;">
                    ✅ Paid on <?= date('M j, Y', strtotime($p['paid_at'])) ?>
                </p>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div class="fr-card text-center py-5">
        <div style="font-size:48px;">💳</div>
        <h5 class="mt-3">No payment records yet.</h5>
        <p class="text-muted">Place an order to see your payments here.</p>
        <a href="home.php" class="btn-primary-fr">Browse Menu</a>
    </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
