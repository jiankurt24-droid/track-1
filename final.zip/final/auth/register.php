<?php
session_start();

// Already logged in → redirect
if (isset($_SESSION['user_id'])) {
    header("Location: /A-J-Foodflix/final_requirement/customer/home.php"); exit();
}

require_once __DIR__ . '/../config/db.php';

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $full_name        = trim($_POST['full_name']        ?? '');
    $email            = trim($_POST['email']            ?? '');
    $password         = $_POST['password']              ?? '';
    $confirm_password = $_POST['confirm_password']      ?? '';
    $phone            = trim($_POST['phone']            ?? '');

    // ── Error trapping ────────────────────────────────────
    if (empty($full_name) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "All required fields must be filled in.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {

        // Check if email already exists
        $check = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "An account with that email already exists.";
        } else {
            // Default role is always 'user' — only existing admin can promote
            $role   = 'user';
            $hashed = password_hash($password, PASSWORD_BCRYPT);

            $insert = $conn->prepare(
                "INSERT INTO users (full_name, email, password, phone, role) VALUES (?, ?, ?, ?, ?)"
            );
            if (!$insert) {
                $error = "Database error: " . $conn->error;
            } else {
                $insert->bind_param("sssss", $full_name, $email, $hashed, $phone, $role);
                if ($insert->execute()) {
                    $success = "Account created! You can now <a href='login.php'>login</a>.";
                } else {
                    // Handle duplicate email at DB level as fallback
                    if ($conn->errno === 1062) {
                        $error = "That email is already registered.";
                    } else {
                        $error = "Registration failed. Please try again.";
                    }
                }
                $insert->close();
            }
        }
        $check->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #f0f0f0; padding: 30px 0; }
        .auth-card {
            width: 100%; max-width: 480px; background: #fff;
            border-radius: 18px; padding: 44px 40px;
            box-shadow: 0 8px 36px rgba(0,0,0,.12);
        }
        .auth-logo { font-size: 26px; font-weight: 900; text-align: center; margin-bottom: 6px; }
        .auth-logo span { color: #e63946; }
        .auth-sub { text-align: center; color: #888; font-size: 14px; margin-bottom: 28px; }
        .form-group { margin-bottom: 16px; }
        label { font-weight: 600; font-size: 13px; display: block; margin-bottom: 6px; }
        .fr-input {
            width: 100%; padding: 11px 14px; border: 1.5px solid #ccc;
            border-radius: 9px; font-size: 14px; outline: none;
        }
        .fr-input:focus { border-color: #111; }
        .required-star { color: #e63946; }
        .role-note {
            background: #f8f9fa; border: 1px solid #dee2e6;
            border-radius: 9px; padding: 12px 16px; font-size: 13px;
            color: #555; margin-bottom: 18px;
        }
        .btn-register {
            width: 100%; padding: 13px; background: #111; color: #fff;
            border: none; border-radius: 9px; font-weight: 700;
            font-size: 15px; cursor: pointer; transition: .2s; margin-top: 4px;
        }
        .btn-register:hover { background: #333; }
        .auth-footer { text-align: center; font-size: 13px; color: #888; margin-top: 22px; }
        .auth-footer a { color: #111; font-weight: 600; }
        .strength-bar { height: 4px; border-radius: 4px; margin-top: 6px; background: #eee; overflow: hidden; }
        .strength-fill { height: 100%; width: 0; transition: .3s; border-radius: 4px; }
    </style>
</head>
<body>
<div class="auth-card">
    <div class="auth-logo">A&amp;J <span>Foodflix</span></div>
    <p class="auth-sub">Create your customer account</p>

    <div class="role-note">
        ℹ️ New accounts are registered as <strong>User</strong> by default. Contact an admin to request role changes.
    </div>

    <?php if ($error): ?>
        <div class="flash-msg flash-error"><?= $error ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="flash-msg flash-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form method="POST" action="" novalidate>

        <div class="form-group">
            <label>Full Name <span class="required-star">*</span></label>
            <input class="fr-input" type="text" name="full_name"
                   placeholder="Juan dela Cruz"
                   value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Email Address <span class="required-star">*</span></label>
            <input class="fr-input" type="email" name="email"
                   placeholder="you@email.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Phone Number</label>
            <input class="fr-input" type="tel" name="phone"
                   placeholder="09XXXXXXXXX"
                   value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
        </div>

        <div class="form-group">
            <label>Password <span class="required-star">*</span> <small style="color:#888;font-weight:400;">(min. 8 characters)</small></label>
            <input class="fr-input" type="password" id="pw" name="password"
                   placeholder="Create a password" required>
            <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
        </div>

        <div class="form-group">
            <label>Confirm Password <span class="required-star">*</span></label>
            <input class="fr-input" type="password" id="pw2" name="confirm_password"
                   placeholder="Repeat your password" required>
            <small id="pw-match-msg" style="font-size:12px;"></small>
        </div>

        <button type="submit" class="btn-register">Create Account</button>

    </form>
    <?php endif; ?>

    <p class="auth-footer">
        Already have an account? <a href="login.php">Login here</a>
    </p>
    <p class="auth-footer">
        <a href="../index.php">← Back to Home</a>
    </p>
</div>

<script>
// Password strength indicator
const pw = document.getElementById('pw');
const fill = document.getElementById('strength-fill');
if (pw) {
    pw.addEventListener('input', () => {
        const v = pw.value;
        let score = 0;
        if (v.length >= 8) score++;
        if (/[A-Z]/.test(v)) score++;
        if (/[0-9]/.test(v)) score++;
        if (/[^A-Za-z0-9]/.test(v)) score++;
        const colors = ['#e63946','#e9c46a','#f4a261','#2d6a4f'];
        fill.style.width = (score * 25) + '%';
        fill.style.background = colors[score - 1] || '#eee';
    });
}

// Password match check
const pw2 = document.getElementById('pw2');
const msg = document.getElementById('pw-match-msg');
if (pw2) {
    pw2.addEventListener('input', () => {
        if (pw.value && pw2.value) {
            if (pw.value === pw2.value) {
                msg.textContent = '✓ Passwords match';
                msg.style.color = '#2d6a4f';
            } else {
                msg.textContent = '✗ Passwords do not match';
                msg.style.color = '#c1121f';
            }
        }
    });
}
</script>
</body>
</html>
