<?php
session_start();

// Already logged in → redirect
if (isset($_SESSION['user_id'])) {
    $dest = $_SESSION['role'] === 'admin'
        ? "/A-J-Foodflix/final/admin/dashboard.php"
        : "/A-J-Foodflix/final/customer/home.php";
    header("Location: $dest"); exit();
}

require_once __DIR__ . '/../config/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Error trapping – empty fields
    if (empty($email) || empty($password)) {
        $error = "Please enter your email and password.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {

        $stmt = $conn->prepare("SELECT user_id, full_name, email, password, role FROM users WHERE email = ?");
        if (!$stmt) {
            $error = "Database error. Please try again.";
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();

                if (password_verify($password, $user['password'])) {
                    // ── Set session ──────────────────────────
                    $_SESSION['user_id']   = $user['user_id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['email']     = $user['email'];
                    $_SESSION['role']      = $user['role'];

                    // ── Redirect by role ─────────────────────
                    if ($user['role'] === 'admin') {
                        header("Location: /A-J-Foodflix/final/admin/dashboard.php");
                    } else {
                        header("Location: /A-J-Foodflix/final/customer/home.php");
                    }
                    exit();
                } else {
                    $error = "Incorrect password. Please try again.";
                }
            } else {
                $error = "No account found with that email.";
            }
            $stmt->close();
        }
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { display: flex; align-items: center; justify-content: center; min-height: 100vh; background: #f0f0f0; }
        .auth-card {
            width: 100%; max-width: 440px;
            background: #fff; border-radius: 18px;
            padding: 44px 40px; box-shadow: 0 8px 36px rgba(0,0,0,.12);
        }
        .auth-logo { font-size: 28px; font-weight: 900; text-align: center; margin-bottom: 6px; }
        .auth-logo span { color: #e63946; }
        .auth-sub { text-align: center; color: #888; font-size: 14px; margin-bottom: 28px; }
        .form-group { margin-bottom: 18px; }
        label { font-weight: 600; font-size: 13px; display: block; margin-bottom: 6px; }
        input[type=email], input[type=password] {
            width: 100%; padding: 11px 14px; border: 1.5px solid #ccc;
            border-radius: 9px; font-size: 14px; outline: none;
        }
        input:focus { border-color: #111; }
        .btn-login {
            width: 100%; padding: 13px; background: #111; color: #fff;
            border: none; border-radius: 9px; font-weight: 700;
            font-size: 15px; cursor: pointer; transition: .2s; margin-top: 4px;
        }
        .btn-login:hover { background: #333; }
        .auth-footer { text-align: center; font-size: 13px; color: #888; margin-top: 22px; }
        .auth-footer a { color: #111; font-weight: 600; }
    </style>
</head>
<body>
<div class="auth-card">
    <div class="auth-logo">A&amp;J <span>Foodflix</span></div>
    <p class="auth-sub">Sign in to your account</p>

    <?php if ($error): ?>
        <div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="" novalidate>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email"
                   placeholder="you@example.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                   required>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   placeholder="Enter your password" required>
        </div>

        <button type="submit" class="btn-login">Login</button>

    </form>

    <p class="auth-footer">
        Don't have an account?
        <a href="register.php">Register here</a>
    </p>
    <p class="auth-footer">
        <a href="../index.php">← Back to Home</a>
    </p>
</div>
</body>
</html>
