<?php
session_start();
session_unset();
session_destroy();
header("Location: /A-J-Foodflix/final/auth/login.php");
exit();
?>
