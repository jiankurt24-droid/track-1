<?php
// includes/navbar.php – shared top navigation
// Expects session to already be started

$base = "/A-J-Foodflix/final/";
$role = $_SESSION['role'] ?? '';
$name = htmlspecialchars($_SESSION['full_name'] ?? 'User');
?>
<nav class="fr-navbar">
    <div class="container d-flex align-items-center gap-3" style="flex-wrap:wrap;">

        <a href="<?= $base ?>index.php" class="brand">
            A&J <span>Foodflix</span>
        </a>

        <div class="d-flex align-items-center gap-1 ms-auto flex-wrap">

            <?php if ($role === 'admin'): ?>
                <a href="<?= $base ?>admin/dashboard.php" class="nav-link-item">Dashboard</a>
                <a href="<?= $base ?>admin/users.php"     class="nav-link-item">Users</a>
                <a href="<?= $base ?>admin/food_items.php"class="nav-link-item">Food Items</a>
                <a href="<?= $base ?>admin/categories.php"class="nav-link-item">Categories</a>
                <a href="<?= $base ?>admin/orders.php"    class="nav-link-item">Orders</a>
                <a href="<?= $base ?>admin/reservations.php" class="nav-link-item">Reservations</a>
                <a href="<?= $base ?>admin/payments.php"  class="nav-link-item">Payments</a>
            <?php elseif ($role === 'user'): ?>
                <a href="<?= $base ?>customer/home.php"         class="nav-link-item">Menu</a>
                <a href="<?= $base ?>customer/my_orders.php"    class="nav-link-item">My Orders</a>
                <a href="<?= $base ?>customer/reservation.php"  class="nav-link-item">Catering</a>
                <a href="<?= $base ?>customer/my_payments.php"  class="nav-link-item">Payments</a>
                <a href="<?= $base ?>customer/account.php"      class="nav-link-item">Account</a>
            <?php endif; ?>

            <?php if ($role): ?>
                <span class="role-pill"><?= strtoupper($role) ?></span>
                <span class="nav-link-item" style="color:#aaa;font-size:13px;"><?= $name ?></span>
                <a href="<?= $base ?>auth/logout.php" class="nav-link-item" style="color:#f4a261;">Logout</a>
            <?php else: ?>
                <a href="<?= $base ?>auth/login.php"    class="nav-link-item">Login</a>
                <a href="<?= $base ?>auth/register.php" class="nav-link-item">Register</a>
            <?php endif; ?>

        </div>

    </div>
</nav>
