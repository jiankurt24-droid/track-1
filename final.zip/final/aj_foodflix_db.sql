-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2026 at 02:30 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aj_foodflix_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `fr_categories`
--

CREATE TABLE `fr_categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fr_categories`
--

INSERT INTO `fr_categories` (`category_id`, `name`, `description`, `created_at`) VALUES
(1, 'Meals', 'Full meal combos and platters', '2026-10-20 11:28:01'),
(2, 'Snacks', 'Light bites and finger food', '2026-10-20 11:28:01'),
(3, 'Beverages', 'Drinks, juices, and shakes', '2026-10-20 11:28:01'),
(4, 'Desserts', 'Sweets and pastries', '2026-10-20 11:28:01'),
(5, 'Catering', 'Bulk / catering packages', '2026-10-20 11:28:01');

-- --------------------------------------------------------

--
-- Table structure for table `fr_food_items`
--

CREATE TABLE `fr_food_items` (
  `item_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock_qty` int(11) NOT NULL DEFAULT 0,
  `image_url` varchar(255) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fr_food_items`
--

INSERT INTO `fr_food_items` (`item_id`, `category_id`, `name`, `description`, `price`, `stock_qty`, `image_url`, `is_available`, `created_at`, `updated_at`) VALUES
(2, 1, 'sardines', 'yummy', 1000.00, 7, NULL, 1, '2026-10-20 11:57:43', '2026-10-20 12:24:52');

-- --------------------------------------------------------

--
-- Table structure for table `fr_orders`
--

CREATE TABLE `fr_orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('pending','confirmed','preparing','ready','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fr_orders`
--

INSERT INTO `fr_orders` (`order_id`, `user_id`, `total_price`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, 5000.00, 'cancelled', '', '2026-10-20 11:57:57', '2026-10-20 11:58:32'),
(2, 1, 4000.00, 'delivered', '', '2026-10-20 11:58:08', '2026-10-20 12:22:26'),
(3, 1, 3000.00, 'pending', '', '2026-10-20 12:24:52', '2026-10-20 12:24:52');

-- --------------------------------------------------------

--
-- Table structure for table `fr_order_items`
--

CREATE TABLE `fr_order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fr_order_items`
--

INSERT INTO `fr_order_items` (`order_item_id`, `order_id`, `item_id`, `quantity`, `unit_price`) VALUES
(1, 1, 2, 5, 1000.00),
(2, 2, 2, 4, 1000.00),
(3, 3, 2, 3, 1000.00);

-- --------------------------------------------------------

--
-- Table structure for table `fr_payments`
--

CREATE TABLE `fr_payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `reservation_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` enum('cash','gcash','card','others') NOT NULL DEFAULT 'cash',
  `status` enum('pending','paid','refunded','failed') NOT NULL DEFAULT 'pending',
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fr_payments`
--

INSERT INTO `fr_payments` (`payment_id`, `order_id`, `reservation_id`, `user_id`, `amount`, `method`, `status`, `paid_at`, `created_at`) VALUES
(1, 1, NULL, 1, 5000.00, 'cash', 'refunded', NULL, '2026-10-20 11:57:57'),
(2, 2, NULL, 1, 4000.00, 'cash', 'paid', '2026-10-20 06:22:43', '2026-10-20 11:58:08'),
(3, 3, NULL, 1, 3000.00, 'gcash', 'pending', NULL, '2026-10-20 12:24:52');

-- --------------------------------------------------------

--
-- Table structure for table `fr_reservations`
--

CREATE TABLE `fr_reservations` (
  `reservation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_name` varchar(150) NOT NULL,
  `event_date` date NOT NULL,
  `guest_count` int(11) NOT NULL,
  `package` varchar(100) DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fr_reservations`
--

INSERT INTO `fr_reservations` (`reservation_id`, `user_id`, `event_name`, `event_date`, `guest_count`, `package`, `status`, `notes`, `created_at`) VALUES
(1, 1, 'birthday', '2026-10-22', 4, 'Premium Package', 'approved', '', '2026-10-20 11:54:39');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password`, `phone`, `role`, `created_at`) VALUES
(1, 'jian kurt ramos', 'jiankurt24@gmail.com', '$2y$10$e8pHZ8Y0tIW00ZfkRxybE.TmM.LiSI48L2bifq.kOa3YwME3BnjTi', '09559487721', 'user', '2026-10-20 11:29:19'),
(3, 'jian kurt ramos', 'foodflixadmin@gmail.com', '$2y$10$wWy8ru3Lrj0smLlBFNsfBeptvwujSLOWtykB1rNuIpZMLV4xmmv2m', '09559487721', 'admin', '2026-10-20 12:21:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fr_categories`
--
ALTER TABLE `fr_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fr_food_items`
--
ALTER TABLE `fr_food_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `fr_orders`
--
ALTER TABLE `fr_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `fr_order_items`
--
ALTER TABLE `fr_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `fr_payments`
--
ALTER TABLE `fr_payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `reservation_id` (`reservation_id`);

--
-- Indexes for table `fr_reservations`
--
ALTER TABLE `fr_reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fr_categories`
--
ALTER TABLE `fr_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fr_food_items`
--
ALTER TABLE `fr_food_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fr_orders`
--
ALTER TABLE `fr_orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fr_order_items`
--
ALTER TABLE `fr_order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fr_payments`
--
ALTER TABLE `fr_payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fr_reservations`
--
ALTER TABLE `fr_reservations`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `fr_food_items`
--
ALTER TABLE `fr_food_items`
  ADD CONSTRAINT `fr_food_items_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `fr_categories` (`category_id`);

--
-- Constraints for table `fr_orders`
--
ALTER TABLE `fr_orders`
  ADD CONSTRAINT `fr_orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `fr_order_items`
--
ALTER TABLE `fr_order_items`
  ADD CONSTRAINT `fr_order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `fr_orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fr_order_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `fr_food_items` (`item_id`);

--
-- Constraints for table `fr_payments`
--
ALTER TABLE `fr_payments`
  ADD CONSTRAINT `fr_payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fr_payments_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `fr_orders` (`order_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fr_payments_ibfk_3` FOREIGN KEY (`reservation_id`) REFERENCES `fr_reservations` (`reservation_id`) ON DELETE SET NULL;

--
-- Constraints for table `fr_reservations`
--
ALTER TABLE `fr_reservations`
  ADD CONSTRAINT `fr_reservations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
