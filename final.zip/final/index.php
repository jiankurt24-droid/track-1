<?php
session_start();
if (isset($_SESSION['user_id'])) {
    $dest = $_SESSION['role'] === 'admin'
        ? "/A-J-Foodflix/final_requirement/admin/dashboard.php"
        : "/A-J-Foodflix/final_requirement/customer/home.php";
    header("Location: $dest"); exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A&amp;J Foodflix – Final Requirement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero {
            min-height: 90vh;
            display: flex;
            align-items: center;
            background: linear-gradient(135deg, #111 60%, #e63946 100%);
            color: #fff;
        }
        .hero h1 { font-size: clamp(2rem, 5vw, 3.5rem); font-weight: 900; }
        .hero p  { font-size: 1.2rem; opacity: .85; max-width: 520px; }
        .hero-cta { display: flex; gap: 14px; flex-wrap: wrap; margin-top: 28px; }
        .hero-cta a {
            padding: 14px 34px; border-radius: 12px; font-weight: 700;
            font-size: 16px; text-decoration: none; transition: .2s;
        }
        .cta-primary { background: #fff; color: #111; }
        .cta-primary:hover { background: #f0f0f0; }
        .cta-outline { border: 2px solid rgba(255,255,255,.6); color: #fff; }
        .cta-outline:hover { background: rgba(255,255,255,.12); }
        .features { padding: 70px 0; }
        .feature-card {
            text-align: center; padding: 32px 20px;
            border: 1px solid #eee; border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,.06); background: #fff;
            transition: .25s;
        }
        .feature-card:hover { transform: translateY(-4px); border-color: #ccc; }
        .feature-icon { font-size: 44px; margin-bottom: 14px; }
        .feature-card h5 { font-weight: 700; }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<!-- Hero -->
<section class="hero">
    <div class="container">
        <h1>🍔 A&amp;J Foodflix</h1>
        <p>Your complete food ordering &amp; restaurant management system. Order your favorite meals, book catering, and track your orders — all in one place.</p>
        <div class="hero-cta">
            <a href="auth/login.php"    class="cta-primary">Login</a>
            <a href="auth/register.php" class="cta-outline">Register</a>
        </div>
    </div>
</section>

<!-- Features -->
<section class="features">
    <div class="container">
        <h2 class="text-center fw-bold mb-5">Everything you need</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">🍽️</div>
                    <h5>Browse the Menu</h5>
                    <p class="text-muted">Explore a wide range of meals, snacks, and beverages with live availability.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">📦</div>
                    <h5>Track Your Orders</h5>
                    <p class="text-muted">Real-time status updates from placement all the way to delivery.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">🎉</div>
                    <h5>Catering &amp; Reservations</h5>
                    <p class="text-muted">Book catering packages for events, parties, or corporate gatherings.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">💳</div>
                    <h5>Easy Payments</h5>
                    <p class="text-muted">Multiple payment methods: cash, GCash, card, and more.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">🛡️</div>
                    <h5>Secure Accounts</h5>
                    <p class="text-muted">Role-based access keeps admin and customer data separate and protected.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">📊</div>
                    <h5>Admin Dashboard</h5>
                    <p class="text-muted">Full CRUD management of products, users, orders, payments, and reports.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<footer class="text-center py-4" style="background:#111;color:#aaa;font-size:13px;">
    &copy; 2026 A&amp;J Foodflix – Final Requirement
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
