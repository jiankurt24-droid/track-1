<?php
// session_guard.php — include at top of any protected page

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: " . getBaseUrl() . "auth/login.php");
        exit();
    }
}

function requireAdmin() {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header("Location: " . getBaseUrl() . "customer/home.php");
        exit();
    }
}

function requireUser() {
    requireLogin();
    if ($_SESSION['role'] !== 'user' && $_SESSION['role'] !== 'admin') {
        header("Location: " . getBaseUrl() . "auth/login.php");
        exit();
    }
}

function getBaseUrl() {
    // Determine the root of final_requirement relative to htdocs
    return "/A-J-Foodflix/final/";
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function currentUserId() {
    return $_SESSION['user_id'] ?? null;
}

function currentUserName() {
    return $_SESSION['full_name'] ?? 'User';
}

function currentRole() {
    return $_SESSION['role'] ?? '';
}
?>
