-- ============================================================
-- A&J Foodflix – Final Requirement Database Setup
-- Run this SQL in phpMyAdmin on the existing aj_foodflix_db
-- ============================================================

USE aj_foodflix_db;

-- ── 1. USERS TABLE ─────────────────────────────────────────
-- Reuse existing users table; ensure columns match
ALTER TABLE users
    MODIFY COLUMN role ENUM('admin','user') NOT NULL DEFAULT 'user';

-- ── 2. CATEGORIES TABLE ────────────────────────────────────
CREATE TABLE IF NOT EXISTS fr_categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed default categories
INSERT IGNORE INTO fr_categories (name, description) VALUES
    ('Meals',     'Full meal combos and platters'),
    ('Snacks',    'Light bites and finger food'),
    ('Beverages', 'Drinks, juices, and shakes'),
    ('Desserts',  'Sweets and pastries'),
    ('Catering',  'Bulk / catering packages');

-- ── 3. FOOD ITEMS TABLE ────────────────────────────────────
CREATE TABLE IF NOT EXISTS fr_food_items (
    item_id     INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name        VARCHAR(150) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock_qty   INT NOT NULL DEFAULT 0,
    image_url   VARCHAR(255) DEFAULT NULL,
    is_available TINYINT(1) NOT NULL DEFAULT 1,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES fr_categories(category_id) ON DELETE RESTRICT
);

-- ── 4. ORDERS TABLE ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fr_orders (
    order_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status      ENUM('pending','confirmed','preparing','ready','delivered','cancelled') NOT NULL DEFAULT 'pending',
    notes       TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ── 5. ORDER ITEMS TABLE ───────────────────────────────────
CREATE TABLE IF NOT EXISTS fr_order_items (
    order_item_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT NOT NULL,
    item_id       INT NOT NULL,
    quantity      INT NOT NULL,
    unit_price    DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES fr_orders(order_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id)  REFERENCES fr_food_items(item_id) ON DELETE RESTRICT
);

-- ── 6. RESERVATIONS TABLE ──────────────────────────────────
CREATE TABLE IF NOT EXISTS fr_reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT NOT NULL,
    event_name     VARCHAR(150) NOT NULL,
    event_date     DATE NOT NULL,
    guest_count    INT NOT NULL,
    package        VARCHAR(100),
    status         ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
    notes          TEXT,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- ── 7. PAYMENTS TABLE ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS fr_payments (
    payment_id   INT AUTO_INCREMENT PRIMARY KEY,
    order_id     INT DEFAULT NULL,
    reservation_id INT DEFAULT NULL,
    user_id      INT NOT NULL,
    amount       DECIMAL(10,2) NOT NULL,
    method       ENUM('cash','gcash','card','others') NOT NULL DEFAULT 'cash',
    status       ENUM('pending','paid','refunded','failed') NOT NULL DEFAULT 'pending',
    paid_at      TIMESTAMP NULL DEFAULT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)     REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (order_id)    REFERENCES fr_orders(order_id) ON DELETE SET NULL,
    FOREIGN KEY (reservation_id) REFERENCES fr_reservations(reservation_id) ON DELETE SET NULL
);
