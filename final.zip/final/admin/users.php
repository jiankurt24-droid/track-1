<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$success = '';
$error   = '';

// ── ADD USER (admin-created accounts only) ─────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email']     ?? '');
    $password  = $_POST['password']       ?? '';
    $phone     = trim($_POST['phone']     ?? '');
    $role      = in_array($_POST['role'] ?? '', ['admin','user']) ? $_POST['role'] : 'user';

    if (empty($full_name) || empty($email) || empty($password)) {
        $error = "Name, email, and password are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters.";
    } else {
        // Prevent creating a second admin if one already exists
        if ($role === 'admin') {
            $adminCount = $conn->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetch_row()[0];
            if ($adminCount >= 1) {
                $error = "Only ONE admin account is allowed. Promote an existing user instead.";
                $role = null; // block insert
            }
        }
        if (!$error && $role !== null) {
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (full_name, email, password, phone, role) VALUES (?,?,?,?,?)");
            $stmt->bind_param("sssss", $full_name, $email, $hashed, $phone, $role);
            if ($stmt->execute()) {
                $success = "User <strong>" . htmlspecialchars($full_name) . "</strong> added successfully.";
            } else {
                $error = $conn->errno === 1062 ? "That email is already registered." : "Failed to add user.";
            }
            $stmt->close();
        }
    }
}

// ── EDIT USER ──────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $uid       = intval($_POST['user_id']);
    $full_name = trim($_POST['full_name'] ?? '');
    $email     = trim($_POST['email']     ?? '');
    $phone     = trim($_POST['phone']     ?? '');
    $role      = in_array($_POST['role'] ?? '', ['admin','user']) ? $_POST['role'] : 'user';
    $new_pw    = $_POST['new_password'] ?? '';

    if (empty($full_name) || empty($email)) {
        $error = "Name and email are required.";
    } else {
        if (!empty($new_pw)) {
            if (strlen($new_pw) < 8) {
                $error = "New password must be at least 8 characters.";
            } else {
                $hashed = password_hash($new_pw, PASSWORD_BCRYPT);
                $stmt = $conn->prepare("UPDATE users SET full_name=?,email=?,phone=?,role=?,password=? WHERE user_id=?");
                $stmt->bind_param("sssssi", $full_name, $email, $phone, $role, $hashed, $uid);
            }
        } else {
            $stmt = $conn->prepare("UPDATE users SET full_name=?,email=?,phone=?,role=? WHERE user_id=?");
            $stmt->bind_param("ssssi", $full_name, $email, $phone, $role, $uid);
        }
        if (!$error) {
            if ($stmt->execute()) {
                $success = "User updated successfully.";
            } else {
                $error = "Failed to update user.";
            }
            $stmt->close();
        }
    }
}

// ── DELETE USER ────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $uid = intval($_GET['delete']);
    // Prevent deleting own account or the only admin
    if ($uid === intval(currentUserId())) {
        $error = "You cannot delete your own account.";
    } else {
        $chk = $conn->query("SELECT role FROM users WHERE user_id=$uid")->fetch_assoc();
        if ($chk && $chk['role'] === 'admin') {
            $error = "The admin account cannot be deleted.";
        } else {
            $conn->query("DELETE FROM users WHERE user_id=$uid");
            $success = "User deleted.";
        }
    }
}

// ── SEARCH & FILTER ────────────────────────────────────────
$search   = trim($_GET['search'] ?? '');
$filter_role = $_GET['role'] ?? '';

$where  = "WHERE 1=1";
$params = [];
$types  = '';

if ($search) {
    $like = "%$search%";
    $where .= " AND (full_name LIKE ? OR email LIKE ?)";
    $params[] = $like; $params[] = $like;
    $types .= 'ss';
}
if ($filter_role === 'admin' || $filter_role === 'user') {
    $where .= " AND role = ?";
    $params[] = $filter_role;
    $types .= 's';
}

$stmt = $conn->prepare("SELECT user_id, full_name, email, phone, role, created_at FROM users $where ORDER BY created_at DESC");
if ($types) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$users = $stmt->get_result();

// ── Edit mode (prefill form) ───────────────────────────────
$edit_user = null;
if (isset($_GET['edit'])) {
    $eid = intval($_GET['edit']);
    $er = $conn->query("SELECT * FROM users WHERE user_id=$eid");
    $edit_user = $er ? $er->fetch_assoc() : null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="container fr-main">

    <?php if ($success): ?>
        <div class="flash-msg flash-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="row g-4">

        <!-- ── USER FORM (Add / Edit) ── -->
        <div class="col-lg-4">
            <div class="fr-card">
                <h4 class="fw-bold mb-4"><?= $edit_user ? '✏️ Edit User' : '➕ Add New User' ?></h4>

                <form method="POST" action="">
                    <input type="hidden" name="action" value="<?= $edit_user ? 'edit' : 'add' ?>">
                    <?php if ($edit_user): ?>
                        <input type="hidden" name="user_id" value="<?= $edit_user['user_id'] ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="fr-form-label">Full Name *</label>
                        <input class="fr-form-control" type="text" name="full_name"
                               value="<?= htmlspecialchars($edit_user['full_name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Email *</label>
                        <input class="fr-form-control" type="email" name="email"
                               value="<?= htmlspecialchars($edit_user['email'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Phone</label>
                        <input class="fr-form-control" type="text" name="phone"
                               value="<?= htmlspecialchars($edit_user['phone'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Role</label>
                        <select class="fr-form-control" name="role">
                            <option value="user"  <?= ($edit_user['role'] ?? 'user') === 'user'  ? 'selected' : '' ?>>User</option>
                            <option value="admin" <?= ($edit_user['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">
                            <?= $edit_user ? 'New Password (leave blank to keep)' : 'Password *' ?>
                        </label>
                        <input class="fr-form-control" type="password"
                               name="<?= $edit_user ? 'new_password' : 'password' ?>"
                               <?= !$edit_user ? 'required' : '' ?>>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-primary-fr">
                            <?= $edit_user ? 'Update User' : 'Add User' ?>
                        </button>
                        <?php if ($edit_user): ?>
                            <a href="users.php" class="btn-outline-fr">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- ── USER TABLE ── -->
        <div class="col-lg-8">
            <div class="fr-card">
                <div class="section-header">
                    <h2>All Users</h2>
                </div>

                <!-- Search & Filter -->
                <form method="GET" class="filter-bar mb-3">
                    <input type="text" name="search" placeholder="🔍 Search name or email..."
                           value="<?= htmlspecialchars($search) ?>">
                    <select name="role">
                        <option value="">All Roles</option>
                        <option value="user"  <?= $filter_role === 'user'  ? 'selected' : '' ?>>User</option>
                        <option value="admin" <?= $filter_role === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                    <button type="submit" class="btn-primary-fr">Filter</button>
                    <a href="users.php" class="btn-outline-fr">Reset</a>
                </form>

                <div class="table-responsive">
                    <table class="fr-table">
                        <thead>
                            <tr>
                                <th>#</th><th>Name</th><th>Email</th><th>Phone</th>
                                <th>Role</th><th>Registered</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($users && $users->num_rows > 0): ?>
                            <?php while ($u = $users->fetch_assoc()): ?>
                            <tr>
                                <td><?= $u['user_id'] ?></td>
                                <td><?= htmlspecialchars($u['full_name']) ?></td>
                                <td><?= htmlspecialchars($u['email']) ?></td>
                                <td><?= htmlspecialchars($u['phone'] ?? '—') ?></td>
                                <td><span class="badge-status badge-<?= $u['role'] ?>"><?= $u['role'] ?></span></td>
                                <td><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
                                <td>
                                    <a href="users.php?edit=<?= $u['user_id'] ?>" class="btn-outline-fr" style="padding:4px 10px;font-size:12px;">Edit</a>
                                    <?php if ($u['user_id'] != currentUserId() && $u['role'] !== 'admin'): ?>
                                        <a href="users.php?delete=<?= $u['user_id'] ?>"
                                           class="btn-danger-fr" style="font-size:12px;padding:4px 10px;"
                                           onclick="return confirm('Delete this user?')">Delete</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center text-muted py-4">No users found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
