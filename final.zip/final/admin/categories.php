<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$success = ''; $error = '';

// ── ADD ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if (empty($name)) { $error = "Category name is required."; }
    else {
        $stmt = $conn->prepare("INSERT INTO fr_categories (name, description) VALUES (?,?)");
        $stmt->bind_param("ss", $name, $desc);
        if ($stmt->execute()) { $success = "Category added."; }
        else { $error = $conn->errno === 1062 ? "Category name already exists." : "Failed to add category."; }
        $stmt->close();
    }
}

// ── EDIT ───────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $cid  = intval($_POST['category_id']);
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    if (empty($name)) { $error = "Category name is required."; }
    else {
        $stmt = $conn->prepare("UPDATE fr_categories SET name=?,description=? WHERE category_id=?");
        $stmt->bind_param("ssi", $name, $desc, $cid);
        $stmt->execute() ? $success = "Category updated." : $error = "Failed to update.";
        $stmt->close();
    }
}

// ── DELETE ─────────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $cid = intval($_GET['delete']);
    $chk = $conn->query("SELECT COUNT(*) FROM fr_food_items WHERE category_id=$cid")->fetch_row()[0];
    if ($chk > 0) {
        $error = "Cannot delete: category has food items. Remove or reassign them first.";
    } else {
        $conn->query("DELETE FROM fr_categories WHERE category_id=$cid");
        $success = "Category deleted.";
    }
}

$edit_cat = null;
if (isset($_GET['edit'])) {
    $r = $conn->query("SELECT * FROM fr_categories WHERE category_id=" . intval($_GET['edit']));
    $edit_cat = $r ? $r->fetch_assoc() : null;
}

$search = trim($_GET['search'] ?? '');
$where  = $search ? "WHERE name LIKE '%" . $conn->real_escape_string($search) . "%'" : '';
$cats   = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM fr_food_items WHERE category_id=c.category_id) AS item_count FROM fr_categories c $where ORDER BY c.name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="row g-4">
        <!-- Form -->
        <div class="col-lg-4">
            <div class="fr-card">
                <h4 class="fw-bold mb-4"><?= $edit_cat ? '✏️ Edit Category' : '➕ Add Category' ?></h4>
                <form method="POST">
                    <input type="hidden" name="action" value="<?= $edit_cat ? 'edit' : 'add' ?>">
                    <?php if ($edit_cat): ?>
                        <input type="hidden" name="category_id" value="<?= $edit_cat['category_id'] ?>">
                    <?php endif; ?>
                    <div class="mb-3">
                        <label class="fr-form-label">Category Name *</label>
                        <input class="fr-form-control" type="text" name="name"
                               value="<?= htmlspecialchars($edit_cat['name'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="fr-form-label">Description</label>
                        <textarea class="fr-form-control" name="description" rows="3"
                                  placeholder="Optional description"><?= htmlspecialchars($edit_cat['description'] ?? '') ?></textarea>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-primary-fr"><?= $edit_cat ? 'Update' : 'Add Category' ?></button>
                        <?php if ($edit_cat): ?><a href="categories.php" class="btn-outline-fr">Cancel</a><?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Table -->
        <div class="col-lg-8">
            <div class="fr-card">
                <div class="section-header">
                    <h2>All Categories</h2>
                </div>
                <form method="GET" class="filter-bar mb-3">
                    <input type="text" name="search" placeholder="🔍 Search category..." value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn-primary-fr">Search</button>
                    <a href="categories.php" class="btn-outline-fr">Reset</a>
                </form>
                <div class="table-responsive">
                    <table class="fr-table">
                        <thead>
                            <tr><th>#</th><th>Name</th><th>Description</th><th>Items</th><th>Actions</th></tr>
                        </thead>
                        <tbody>
                        <?php if ($cats && $cats->num_rows > 0): ?>
                            <?php while ($c = $cats->fetch_assoc()): ?>
                            <tr>
                                <td><?= $c['category_id'] ?></td>
                                <td><?= htmlspecialchars($c['name']) ?></td>
                                <td><?= htmlspecialchars($c['description'] ?? '—') ?></td>
                                <td><span class="badge-status badge-confirmed"><?= $c['item_count'] ?> items</span></td>
                                <td>
                                    <a href="categories.php?edit=<?= $c['category_id'] ?>" class="btn-outline-fr" style="padding:4px 10px;font-size:12px;">Edit</a>
                                    <a href="categories.php?delete=<?= $c['category_id'] ?>" class="btn-danger-fr" style="font-size:12px;padding:4px 10px;"
                                       onclick="return confirm('Delete this category?')">Delete</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">No categories found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
