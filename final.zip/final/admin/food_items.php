<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$success = ''; $error = '';

// ── ADD ────────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    $cat_id   = intval($_POST['category_id'] ?? 0);
    $name     = trim($_POST['name']        ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $price    = floatval($_POST['price']   ?? 0);
    $stock    = intval($_POST['stock_qty'] ?? 0);
    $avail    = isset($_POST['is_available']) ? 1 : 0;
    $img      = trim($_POST['image_url']   ?? '');

    if (empty($name) || $cat_id === 0 || $price <= 0) {
        $error = "Name, category, and a valid price are required.";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO fr_food_items (category_id,name,description,price,stock_qty,is_available,image_url) VALUES (?,?,?,?,?,?,?)"
        );
        $stmt->bind_param("issdiss", $cat_id, $name, $desc, $price, $stock, $avail, $img);
        $stmt->execute() ? $success = "Food item added." : $error = "Failed to add item.";
        $stmt->close();
    }
}

// ── EDIT ───────────────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $iid    = intval($_POST['item_id']);
    $cat_id = intval($_POST['category_id'] ?? 0);
    $name   = trim($_POST['name']        ?? '');
    $desc   = trim($_POST['description'] ?? '');
    $price  = floatval($_POST['price']   ?? 0);
    $stock  = intval($_POST['stock_qty'] ?? 0);
    $avail  = isset($_POST['is_available']) ? 1 : 0;
    $img    = trim($_POST['image_url']   ?? '');

    if (empty($name) || $cat_id === 0 || $price <= 0) {
        $error = "Name, category, and a valid price are required.";
    } else {
        $stmt = $conn->prepare(
            "UPDATE fr_food_items SET category_id=?,name=?,description=?,price=?,stock_qty=?,is_available=?,image_url=? WHERE item_id=?"
        );
        $stmt->bind_param("issdissi", $cat_id, $name, $desc, $price, $stock, $avail, $img, $iid);
        $stmt->execute() ? $success = "Item updated." : $error = "Failed to update.";
        $stmt->close();
    }
}

// ── DELETE ─────────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $iid = intval($_GET['delete']);
    $chk = $conn->query("SELECT COUNT(*) FROM fr_order_items WHERE item_id=$iid")->fetch_row()[0];
    if ($chk > 0) {
        $error = "Cannot delete: item is linked to existing orders.";
    } else {
        $conn->query("DELETE FROM fr_food_items WHERE item_id=$iid");
        $success = "Item deleted.";
    }
}

// ── TOGGLE AVAILABILITY ────────────────────────────────────
if (isset($_GET['toggle'])) {
    $iid = intval($_GET['toggle']);
    $conn->query("UPDATE fr_food_items SET is_available = !is_available WHERE item_id=$iid");
    header("Location: food_items.php"); exit();
}

// ── Fetch edit item ────────────────────────────────────────
$edit_item = null;
if (isset($_GET['edit'])) {
    $r = $conn->query("SELECT * FROM fr_food_items WHERE item_id=" . intval($_GET['edit']));
    $edit_item = $r ? $r->fetch_assoc() : null;
}

// ── Search / Filter ────────────────────────────────────────
$search   = trim($_GET['search']   ?? '');
$cat_filt = intval($_GET['cat']    ?? 0);
$avail_f  = $_GET['avail']         ?? '';

$where = "WHERE 1=1";
if ($search)   $where .= " AND f.name LIKE '%" . $conn->real_escape_string($search) . "%'";
if ($cat_filt) $where .= " AND f.category_id = $cat_filt";
if ($avail_f === '1') $where .= " AND f.is_available = 1";
if ($avail_f === '0') $where .= " AND f.is_available = 0";

$items = $conn->query(
    "SELECT f.*, c.name AS cat_name FROM fr_food_items f
     JOIN fr_categories c ON f.category_id = c.category_id
     $where ORDER BY f.created_at DESC"
);
$categories = $conn->query("SELECT * FROM fr_categories ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Items – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="row g-4">

        <!-- ── Form ── -->
        <div class="col-lg-4">
            <div class="fr-card">
                <h4 class="fw-bold mb-4"><?= $edit_item ? '✏️ Edit Item' : '➕ Add Food Item' ?></h4>
                <form method="POST">
                    <input type="hidden" name="action" value="<?= $edit_item ? 'edit' : 'add' ?>">
                    <?php if ($edit_item): ?>
                        <input type="hidden" name="item_id" value="<?= $edit_item['item_id'] ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="fr-form-label">Category *</label>
                        <select class="fr-form-control" name="category_id" required>
                            <option value="">-- Select Category --</option>
                            <?php
                            $categories->data_seek(0);
                            while ($c = $categories->fetch_assoc()):
                                $sel = ($edit_item['category_id'] ?? '') == $c['category_id'] ? 'selected' : '';
                            ?>
                            <option value="<?= $c['category_id'] ?>" <?= $sel ?>><?= htmlspecialchars($c['name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="fr-form-label">Name *</label>
                        <input class="fr-form-control" type="text" name="name"
                               value="<?= htmlspecialchars($edit_item['name'] ?? '') ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="fr-form-label">Description</label>
                        <textarea class="fr-form-control" name="description" rows="2"><?= htmlspecialchars($edit_item['description'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="fr-form-label">Price (₱) *</label>
                        <input class="fr-form-control" type="number" step="0.01" name="price" min="0.01"
                               value="<?= $edit_item['price'] ?? '' ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="fr-form-label">Stock Quantity</label>
                        <input class="fr-form-control" type="number" name="stock_qty" min="0"
                               value="<?= $edit_item['stock_qty'] ?? 0 ?>">
                    </div>

                    <div class="mb-3">
                        <label class="fr-form-label">Image URL (optional)</label>
                        <input class="fr-form-control" type="url" name="image_url"
                               placeholder="https://..." value="<?= htmlspecialchars($edit_item['image_url'] ?? '') ?>">
                    </div>

                    <div class="mb-3 d-flex align-items-center gap-2">
                        <input type="checkbox" id="avail" name="is_available"
                               <?= (!isset($edit_item) || $edit_item['is_available']) ? 'checked' : '' ?>>
                        <label for="avail" class="mb-0 fw-semibold">Available for order</label>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-primary-fr"><?= $edit_item ? 'Update Item' : 'Add Item' ?></button>
                        <?php if ($edit_item): ?><a href="food_items.php" class="btn-outline-fr">Cancel</a><?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- ── Table ── -->
        <div class="col-lg-8">
            <div class="fr-card">
                <div class="section-header">
                    <h2>All Food Items</h2>
                </div>

                <!-- Filter bar -->
                <form method="GET" class="filter-bar">
                    <input type="text" name="search" placeholder="🔍 Search item..." value="<?= htmlspecialchars($search) ?>">
                    <select name="cat">
                        <option value="">All Categories</option>
                        <?php
                        $categories->data_seek(0);
                        while ($c = $categories->fetch_assoc()):
                            $sel = $cat_filt == $c['category_id'] ? 'selected' : '';
                        ?>
                        <option value="<?= $c['category_id'] ?>" <?= $sel ?>><?= htmlspecialchars($c['name']) ?></option>
                        <?php endwhile; ?>
                    </select>
                    <select name="avail">
                        <option value="">All Status</option>
                        <option value="1" <?= $avail_f === '1' ? 'selected' : '' ?>>Available</option>
                        <option value="0" <?= $avail_f === '0' ? 'selected' : '' ?>>Unavailable</option>
                    </select>
                    <button type="submit" class="btn-primary-fr">Filter</button>
                    <a href="food_items.php" class="btn-outline-fr">Reset</a>
                </form>

                <div class="table-responsive">
                    <table class="fr-table">
                        <thead>
                            <tr>
                                <th>#</th><th>Name</th><th>Category</th>
                                <th>Price</th><th>Stock</th><th>Status</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($items && $items->num_rows > 0): ?>
                            <?php while ($row = $items->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['item_id'] ?></td>
                                <td>
                                    <?php if ($row['image_url']): ?>
                                        <img src="<?= htmlspecialchars($row['image_url']) ?>"
                                             style="width:38px;height:38px;object-fit:cover;border-radius:8px;margin-right:8px;" alt="">
                                    <?php endif; ?>
                                    <?= htmlspecialchars($row['name']) ?>
                                </td>
                                <td><?= htmlspecialchars($row['cat_name']) ?></td>
                                <td>₱<?= number_format($row['price'], 2) ?></td>
                                <td><?= $row['stock_qty'] ?></td>
                                <td>
                                    <a href="food_items.php?toggle=<?= $row['item_id'] ?>">
                                        <span class="badge-status <?= $row['is_available'] ? 'badge-delivered' : 'badge-cancelled' ?>">
                                            <?= $row['is_available'] ? 'Available' : 'Unavailable' ?>
                                        </span>
                                    </a>
                                </td>
                                <td>
                                    <a href="food_items.php?edit=<?= $row['item_id'] ?>" class="btn-outline-fr" style="padding:4px 10px;font-size:12px;">Edit</a>
                                    <a href="food_items.php?delete=<?= $row['item_id'] ?>" class="btn-danger-fr" style="font-size:12px;padding:4px 10px;"
                                       onclick="return confirm('Delete this item?')">Del</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="7" class="text-center text-muted py-4">No items found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
