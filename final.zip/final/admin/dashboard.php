<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

// ── Fetch stat counts ──────────────────────────────────────
$stats = [];
$queries = [
    'users'        => "SELECT COUNT(*) FROM users WHERE role='user'",
    'food_items'   => "SELECT COUNT(*) FROM fr_food_items",
    'orders'       => "SELECT COUNT(*) FROM fr_orders",
    'pending_orders' => "SELECT COUNT(*) FROM fr_orders WHERE status='pending'",
    'reservations' => "SELECT COUNT(*) FROM fr_reservations",
    'revenue'      => "SELECT IFNULL(SUM(amount),0) FROM fr_payments WHERE status='paid'",
];
foreach ($queries as $key => $q) {
    $r = $conn->query($q);
    $stats[$key] = $r ? $r->fetch_row()[0] : 0;
}

// ── Recent Orders ──────────────────────────────────────────
$recent_orders = $conn->query(
    "SELECT o.order_id, u.full_name, o.total_price, o.status, o.created_at
     FROM fr_orders o
     JOIN users u ON o.user_id = u.user_id
     ORDER BY o.created_at DESC LIMIT 8"
);

// ── Recent Registrations ───────────────────────────────────
$recent_users = $conn->query(
    "SELECT user_id, full_name, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 6"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="container fr-main">

    <!-- Welcome -->
    <div class="fr-card mb-4" style="background:#111;color:#fff;border:none;">
        <h2 class="mb-1">Welcome back, <?= htmlspecialchars(currentUserName()) ?>!</h2>
        <p class="mb-0" style="color:#aaa;">A&amp;J Foodflix Admin Dashboard — <?= date('F j, Y') ?></p>
    </div>

    <!-- Stat Cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="stat-card blue">
                <div class="stat-icon">👤</div>
                <div>
                    <div class="stat-value"><?= $stats['users'] ?></div>
                    <div class="stat-label">Registered Users</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card red">
                <div class="stat-icon">📦</div>
                <div>
                    <div class="stat-value"><?= $stats['orders'] ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card yellow">
                <div class="stat-icon">⏳</div>
                <div>
                    <div class="stat-value"><?= $stats['pending_orders'] ?></div>
                    <div class="stat-label">Pending Orders</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card green">
                <div class="stat-icon">💰</div>
                <div>
                    <div class="stat-value">₱<?= number_format($stats['revenue'], 2) ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Links -->
    <div class="row g-3 mb-4">
        <?php
        $links = [
            ['users.php',       '👥', 'Manage Users',       'View, add, edit, and delete user accounts.'],
            ['food_items.php',  '🍔', 'Food Items',          'Full CRUD for all menu items.'],
            ['categories.php',  '🏷️', 'Categories',         'Organize food items by category.'],
            ['orders.php',      '📦', 'Orders',              'View and update all customer orders.'],
            ['reservations.php','🎉', 'Reservations',        'Manage catering reservation requests.'],
            ['payments.php',    '💳', 'Payments',            'View and track payment records.'],
        ];
        foreach ($links as [$href, $icon, $title, $desc]):
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="fr-card h-100">
                <div style="font-size:32px;margin-bottom:10px;"><?= $icon ?></div>
                <h5 class="fw-bold"><?= $title ?></h5>
                <p class="text-muted" style="font-size:13px;"><?= $desc ?></p>
                <a href="<?= $href ?>" class="btn-primary-fr">Open →</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Recent Orders Table -->
    <div class="fr-card mb-4">
        <div class="section-header">
            <h2>Recent Orders</h2>
            <a href="orders.php" class="btn-outline-fr">View All</a>
        </div>
        <div class="table-responsive">
            <table class="fr-table">
                <thead>
                    <tr>
                        <th>#ID</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($recent_orders && $recent_orders->num_rows > 0): ?>
                    <?php while ($row = $recent_orders->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['order_id'] ?></td>
                        <td><?= htmlspecialchars($row['full_name']) ?></td>
                        <td>₱<?= number_format($row['total_price'], 2) ?></td>
                        <td><span class="badge-status badge-<?= $row['status'] ?>"><?= $row['status'] ?></span></td>
                        <td><?= date('M j, Y', strtotime($row['created_at'])) ?></td>
                        <td><a href="orders.php?id=<?= $row['order_id'] ?>" class="btn-outline-fr" style="padding:5px 12px;font-size:12px;">View</a></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No orders yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Recent Users -->
    <div class="fr-card">
        <div class="section-header">
            <h2>Recently Registered Users</h2>
            <a href="users.php" class="btn-outline-fr">View All</a>
        </div>
        <div class="table-responsive">
            <table class="fr-table">
                <thead>
                    <tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Registered</th></tr>
                </thead>
                <tbody>
                <?php if ($recent_users && $recent_users->num_rows > 0): ?>
                    <?php while ($u = $recent_users->fetch_assoc()): ?>
                    <tr>
                        <td><?= $u['user_id'] ?></td>
                        <td><?= htmlspecialchars($u['full_name']) ?></td>
                        <td><?= htmlspecialchars($u['email']) ?></td>
                        <td><span class="badge-status badge-<?= $u['role'] ?>"><?= $u['role'] ?></span></td>
                        <td><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No users found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
