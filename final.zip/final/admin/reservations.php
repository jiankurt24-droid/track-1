<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$success = ''; $error = '';

// ── UPDATE STATUS ──────────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $rid    = intval($_POST['reservation_id']);
    $status = $_POST['status'] ?? '';
    $allowed = ['pending','approved','rejected','cancelled'];
    if (!in_array($status, $allowed)) { $error = "Invalid status."; }
    else {
        $stmt = $conn->prepare("UPDATE fr_reservations SET status=? WHERE reservation_id=?");
        $stmt->bind_param("si", $status, $rid);
        $stmt->execute() ? $success = "Reservation #$rid updated to <strong>$status</strong>." : $error = "Update failed.";
        $stmt->close();
    }
}

// ── Filter ─────────────────────────────────────────────────
$search      = trim($_GET['search'] ?? '');
$status_filt = $_GET['status']      ?? '';

$where = "WHERE 1=1";
if ($search) $where .= " AND (u.full_name LIKE '%" . $conn->real_escape_string($search) . "%' OR r.event_name LIKE '%" . $conn->real_escape_string($search) . "%')";
if (in_array($status_filt, ['pending','approved','rejected','cancelled'])) $where .= " AND r.status='$status_filt'";

$reservations = $conn->query(
    "SELECT r.*, u.full_name, u.email FROM fr_reservations r
     JOIN users u ON r.user_id=u.user_id $where ORDER BY r.created_at DESC"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservations – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="fr-card">
        <div class="section-header"><h2>Catering Reservations</h2></div>

        <form method="GET" class="filter-bar">
            <input type="text" name="search" placeholder="🔍 Customer or event name..." value="<?= htmlspecialchars($search) ?>">
            <select name="status">
                <option value="">All Status</option>
                <?php foreach (['pending','approved','rejected','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $status_filt === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-primary-fr">Filter</button>
            <a href="reservations.php" class="btn-outline-fr">Reset</a>
        </form>

        <!-- Card / Comprehensive view -->
        <?php if ($reservations && $reservations->num_rows > 0): ?>
            <div class="row g-3 mt-1">
            <?php while ($r = $reservations->fetch_assoc()): ?>
            <div class="col-md-6">
                <div class="fr-card" style="padding:22px;">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <h5 class="fw-bold mb-1"><?= htmlspecialchars($r['event_name']) ?></h5>
                            <small class="text-muted">Reservation #<?= $r['reservation_id'] ?></small>
                        </div>
                        <span class="badge-status badge-<?= $r['status'] ?>"><?= $r['status'] ?></span>
                    </div>
                    <div class="row g-2 mb-3" style="font-size:14px;">
                        <div class="col-6"><strong>👤 Customer:</strong><br><?= htmlspecialchars($r['full_name']) ?></div>
                        <div class="col-6"><strong>📅 Event Date:</strong><br><?= date('M j, Y', strtotime($r['event_date'])) ?></div>
                        <div class="col-6"><strong>👥 Guests:</strong><br><?= $r['guest_count'] ?> persons</div>
                        <div class="col-6"><strong>📦 Package:</strong><br><?= htmlspecialchars($r['package'] ?? '—') ?></div>
                        <div class="col-12"><strong>📝 Notes:</strong><br><?= htmlspecialchars($r['notes'] ?? '—') ?></div>
                    </div>
                    <form method="POST" class="d-flex gap-2">
                        <input type="hidden" name="action"         value="update_status">
                        <input type="hidden" name="reservation_id" value="<?= $r['reservation_id'] ?>">
                        <select class="fr-form-control" name="status" style="max-width:160px;">
                            <?php foreach (['pending','approved','rejected','cancelled'] as $s): ?>
                            <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn-primary-fr">Update</button>
                    </form>
                </div>
            </div>
            <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-muted text-center mt-4">No reservations found.</p>
        <?php endif; ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
