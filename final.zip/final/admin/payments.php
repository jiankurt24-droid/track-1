<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$success = ''; $error = '';

// ── UPDATE PAYMENT STATUS ──────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update') {
    $pid    = intval($_POST['payment_id']);
    $status = $_POST['status'] ?? '';
    $allowed = ['pending','paid','refunded','failed'];
    if (!in_array($status, $allowed)) { $error = "Invalid status."; }
    else {
        $paid_at = $status === 'paid' ? date('Y-m-d H:i:s') : null;
        $stmt = $conn->prepare("UPDATE fr_payments SET status=?, paid_at=? WHERE payment_id=?");
        $stmt->bind_param("ssi", $status, $paid_at, $pid);
        $stmt->execute() ? $success = "Payment #$pid updated." : $error = "Update failed.";
        $stmt->close();
    }
}

// ── Filter ─────────────────────────────────────────────────
$search      = trim($_GET['search'] ?? '');
$status_filt = $_GET['status']      ?? '';
$method_filt = $_GET['method']      ?? '';

$where = "WHERE 1=1";
if ($search)   $where .= " AND (u.full_name LIKE '%" . $conn->real_escape_string($search) . "%')";
if (in_array($status_filt, ['pending','paid','refunded','failed'])) $where .= " AND p.status='$status_filt'";
if (in_array($method_filt, ['cash','gcash','card','others']))       $where .= " AND p.method='$method_filt'";

$payments = $conn->query(
    "SELECT p.*, u.full_name FROM fr_payments p
     JOIN users u ON p.user_id=u.user_id $where ORDER BY p.created_at DESC"
);

// Totals
$totals = $conn->query("SELECT status, SUM(amount) as total FROM fr_payments GROUP BY status")->fetch_all(MYSQLI_ASSOC);
$totals_map = [];
foreach ($totals as $t) $totals_map[$t['status']] = $t['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Summary stat cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="stat-card green">
                <div class="stat-icon">✅</div>
                <div>
                    <div class="stat-value">₱<?= number_format($totals_map['paid'] ?? 0, 2) ?></div>
                    <div class="stat-label">Paid</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card yellow">
                <div class="stat-icon">⏳</div>
                <div>
                    <div class="stat-value">₱<?= number_format($totals_map['pending'] ?? 0, 2) ?></div>
                    <div class="stat-label">Pending</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card blue">
                <div class="stat-icon">🔄</div>
                <div>
                    <div class="stat-value">₱<?= number_format($totals_map['refunded'] ?? 0, 2) ?></div>
                    <div class="stat-label">Refunded</div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card red">
                <div class="stat-icon">❌</div>
                <div>
                    <div class="stat-value">₱<?= number_format($totals_map['failed'] ?? 0, 2) ?></div>
                    <div class="stat-label">Failed</div>
                </div>
            </div>
        </div>
    </div>

    <div class="fr-card">
        <div class="section-header"><h2>Payment Records</h2></div>

        <form method="GET" class="filter-bar">
            <input type="text" name="search" placeholder="🔍 Customer name..." value="<?= htmlspecialchars($search) ?>">
            <select name="status">
                <option value="">All Status</option>
                <?php foreach (['pending','paid','refunded','failed'] as $s): ?>
                <option value="<?= $s ?>" <?= $status_filt === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="method">
                <option value="">All Methods</option>
                <?php foreach (['cash','gcash','card','others'] as $m): ?>
                <option value="<?= $m ?>" <?= $method_filt === $m ? 'selected' : '' ?>><?= ucfirst($m) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-primary-fr">Filter</button>
            <a href="payments.php" class="btn-outline-fr">Reset</a>
        </form>

        <div class="table-responsive">
            <table class="fr-table">
                <thead>
                    <tr><th>#</th><th>Customer</th><th>Order/Res</th><th>Amount</th><th>Method</th><th>Status</th><th>Paid At</th><th>Update</th></tr>
                </thead>
                <tbody>
                <?php if ($payments && $payments->num_rows > 0): ?>
                    <?php while ($p = $payments->fetch_assoc()): ?>
                    <tr>
                        <td><?= $p['payment_id'] ?></td>
                        <td><?= htmlspecialchars($p['full_name']) ?></td>
                        <td>
                            <?= $p['order_id']       ? "Order #" . $p['order_id']         : '' ?>
                            <?= $p['reservation_id']  ? "Res #" . $p['reservation_id']     : '' ?>
                            <?= (!$p['order_id'] && !$p['reservation_id']) ? '—' : '' ?>
                        </td>
                        <td>₱<?= number_format($p['amount'], 2) ?></td>
                        <td><?= ucfirst($p['method']) ?></td>
                        <td><span class="badge-status badge-<?= $p['status'] ?>"><?= $p['status'] ?></span></td>
                        <td><?= $p['paid_at'] ? date('M j, Y', strtotime($p['paid_at'])) : '—' ?></td>
                        <td>
                            <form method="POST" class="d-flex gap-1">
                                <input type="hidden" name="action"     value="update">
                                <input type="hidden" name="payment_id" value="<?= $p['payment_id'] ?>">
                                <select name="status" class="fr-form-control" style="min-width:100px;padding:5px 8px;font-size:12px;">
                                    <?php foreach (['pending','paid','refunded','failed'] as $s): ?>
                                    <option value="<?= $s ?>" <?= $p['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn-primary-fr" style="padding:5px 10px;font-size:12px;">✓</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">No payments found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
