<?php
session_start();
require_once __DIR__ . '/../config/session_guard.php';
requireAdmin();
require_once __DIR__ . '/../config/db.php';

$success = ''; $error = '';

// ── UPDATE ORDER STATUS ────────────────────────────────────
if (isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $oid    = intval($_POST['order_id']);
    $status = $_POST['status'] ?? '';
    $allowed = ['pending','confirmed','preparing','ready','delivered','cancelled'];
    if (!in_array($status, $allowed)) {
        $error = "Invalid status.";
    } else {
        $stmt = $conn->prepare("UPDATE fr_orders SET status=? WHERE order_id=?");
        $stmt->bind_param("si", $status, $oid);
        $stmt->execute() ? $success = "Order #$oid status updated to <strong>$status</strong>." : $error = "Update failed.";
        $stmt->close();
    }
}

// ── Search / Filter ────────────────────────────────────────
$search      = trim($_GET['search']    ?? '');
$status_filt = $_GET['status']         ?? '';

$where  = "WHERE 1=1";
$params = []; $types = '';

if ($search) {
    $like = "%$search%";
    $where .= " AND (u.full_name LIKE ? OR u.email LIKE ? OR o.order_id LIKE ?)";
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types .= 'sss';
}
$allowed_statuses = ['pending','confirmed','preparing','ready','delivered','cancelled'];
if (in_array($status_filt, $allowed_statuses)) {
    $where .= " AND o.status = ?";
    $params[] = $status_filt;
    $types .= 's';
}

$sql  = "SELECT o.*, u.full_name, u.email FROM fr_orders o JOIN users u ON o.user_id=u.user_id $where ORDER BY o.created_at DESC";
$stmt = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$orders = $stmt->get_result();

// ── Single order detail ────────────────────────────────────
$view_order = null;
$order_items = null;
if (isset($_GET['id'])) {
    $oid = intval($_GET['id']);
    $r = $conn->query(
        "SELECT o.*, u.full_name, u.email, u.phone FROM fr_orders o
         JOIN users u ON o.user_id=u.user_id WHERE o.order_id=$oid"
    );
    $view_order = $r ? $r->fetch_assoc() : null;
    if ($view_order) {
        $order_items = $conn->query(
            "SELECT oi.*, f.name AS food_name, f.image_url FROM fr_order_items oi
             JOIN fr_food_items f ON oi.item_id=f.item_id WHERE oi.order_id=$oid"
        );
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders – A&amp;J Foodflix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="container fr-main">

    <?php if ($success): ?><div class="flash-msg flash-success"><?= $success ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="flash-msg flash-error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if ($view_order): ?>
    <!-- ── ORDER DETAIL VIEW ── -->
    <div class="fr-card mb-4">
        <a href="orders.php" class="btn-outline-fr mb-3" style="display:inline-block;">← Back to Orders</a>
        <h3 class="fw-bold">Order #<?= $view_order['order_id'] ?> Detail</h3>
        <div class="row mt-3">
            <div class="col-md-6">
                <p><strong>Customer:</strong> <?= htmlspecialchars($view_order['full_name']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($view_order['email']) ?></p>
                <p><strong>Phone:</strong> <?= htmlspecialchars($view_order['phone'] ?? '—') ?></p>
                <p><strong>Date:</strong> <?= date('F j, Y g:i A', strtotime($view_order['created_at'])) ?></p>
            </div>
            <div class="col-md-6">
                <p><strong>Total:</strong> <span style="font-size:20px;font-weight:800;color:#e63946;">₱<?= number_format($view_order['total_price'], 2) ?></span></p>
                <p><strong>Status:</strong> <span class="badge-status badge-<?= $view_order['status'] ?>"><?= $view_order['status'] ?></span></p>
                <p><strong>Notes:</strong> <?= htmlspecialchars($view_order['notes'] ?? '—') ?></p>

                <!-- Update status form -->
                <form method="POST" class="d-flex gap-2 align-items-center mt-3">
                    <input type="hidden" name="action"   value="update_status">
                    <input type="hidden" name="order_id" value="<?= $view_order['order_id'] ?>">
                    <select class="fr-form-control" name="status" style="max-width:180px;">
                        <?php foreach (['pending','confirmed','preparing','ready','delivered','cancelled'] as $s): ?>
                        <option value="<?= $s ?>" <?= $view_order['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn-primary-fr">Update</button>
                </form>
            </div>
        </div>

        <h5 class="fw-bold mt-4">Ordered Items</h5>
        <table class="fr-table">
            <thead><tr><th>Item</th><th>Unit Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
            <tbody>
            <?php if ($order_items && $order_items->num_rows > 0): ?>
                <?php while ($oi = $order_items->fetch_assoc()): ?>
                <tr>
                    <td>
                        <?php if ($oi['image_url']): ?>
                            <img src="<?= htmlspecialchars($oi['image_url']) ?>" style="width:36px;height:36px;object-fit:cover;border-radius:6px;margin-right:8px;">
                        <?php endif; ?>
                        <?= htmlspecialchars($oi['food_name']) ?>
                    </td>
                    <td>₱<?= number_format($oi['unit_price'], 2) ?></td>
                    <td><?= $oi['quantity'] ?></td>
                    <td>₱<?= number_format($oi['unit_price'] * $oi['quantity'], 2) ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4" class="text-muted text-center">No items.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php else: ?>
    <!-- ── ORDERS LIST ── -->
    <div class="fr-card">
        <div class="section-header">
            <h2>All Orders</h2>
        </div>

        <form method="GET" class="filter-bar">
            <input type="text" name="search" placeholder="🔍 Customer, email, or #ID..." value="<?= htmlspecialchars($search) ?>">
            <select name="status">
                <option value="">All Status</option>
                <?php foreach (['pending','confirmed','preparing','ready','delivered','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $status_filt === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-primary-fr">Filter</button>
            <a href="orders.php" class="btn-outline-fr">Reset</a>
        </form>

        <div class="table-responsive">
            <table class="fr-table">
                <thead>
                    <tr><th>#</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th>Action</th></tr>
                </thead>
                <tbody>
                <?php if ($orders && $orders->num_rows > 0): ?>
                    <?php while ($o = $orders->fetch_assoc()): ?>
                    <tr>
                        <td><?= $o['order_id'] ?></td>
                        <td>
                            <strong><?= htmlspecialchars($o['full_name']) ?></strong><br>
                            <small class="text-muted"><?= htmlspecialchars($o['email']) ?></small>
                        </td>
                        <td>₱<?= number_format($o['total_price'], 2) ?></td>
                        <td><span class="badge-status badge-<?= $o['status'] ?>"><?= $o['status'] ?></span></td>
                        <td><?= date('M j, Y', strtotime($o['created_at'])) ?></td>
                        <td><a href="orders.php?id=<?= $o['order_id'] ?>" class="btn-outline-fr" style="padding:5px 12px;font-size:12px;">View</a></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center text-muted py-4">No orders found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php $conn->close(); ?>
